package ru.poker.Interfaces;

public interface Progress {
    void initGame();

    void progress();
}
